# Carpeta del equipo AVIM

Este folder es para todo el software del equipo AVIM.
Colocar en este README las instrucciones para ejecutar dichos códigos. 

Primera prueba ejecutar:
Abrir una terminal:
-cd ~/catkin_ws
-source devel/setup.bash 
-roslaunch bring_up navigation_without_obstacles.launch

Abrir otra terminal:
-cd ~/catkin_ws
-source devel/setup.bash 
-roslaunch AVIM navigation_without_obstacles.launch

Segunda prueba ejecutar:
Abrir una terminal:
-cd ~/catkin_ws
-source devel/setup.bash 
-roslaunch bring_up navigation_with_static_obstacles.launch

Abrir otra terminal:
-cd ~/catkin_ws
-source devel/setup.bash 
-roslaunch AVIM navigation_with_static_obstacles.launch

Tercera prueba ejecutar:
Abrir una terminal:
-cd ~/catkin_ws
-source devel/setup.bash 
-roslaunch bring_up navigation_with_dynamic_obstacles.launch


Abrir otra terminal:
-cd ~/catkin_ws
-source devel/setup.bash 
-roslaunch AVIM navigation_with_dynamic_obstacles.launch

Cuarta prueba ejecutar:

En proceso


