
"use strict";

let points_objects = require('./points_objects.js');

module.exports = {
  points_objects: points_objects,
};
