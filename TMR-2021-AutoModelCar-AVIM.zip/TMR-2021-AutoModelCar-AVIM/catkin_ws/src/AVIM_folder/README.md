# TMR 2021 - AVIM
<p>Para compilar:</p> 
<p>cd catkin_ws y compilar</p>
<p> Si marca error</p>
<p>Eliminar la carpeta devel, sacar de catkin_ws la carpeta AVIM_folder, despues compilar, una vez compilo sin la carpeta AVIM_folder, ingresar de nuevo la carpeta donde estaba catkin_ws/src y compilar </p>
<p>Ejecución de la primer prueba:</p>
<p>Abrir una terminal y ejecutar</p>
<p>cd catkin_ws</p>
<p>source devel/setup.bash</p>
<p>roslaunch bring_up navigation_without_obstacles.launch</p>
<p>Abrir otra terminal y ejecutar</p>
<p>cd catkin_ws</p>
<p>source devel/setup.bash</p>
<p>roslaunch AVIM navigation_without_obstacles.launch</p>

